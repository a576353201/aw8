<template>
	<view>
		<view class="edgeInsetTop"></view>
		
		
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		}
	}
</script>

<style>
	
</style>
